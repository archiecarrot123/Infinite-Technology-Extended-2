pack_set_nc =
{
    {"automation-science-pack", 1}, {"science-pack-2", 1}, {"chemical-science-pack", 1},
    {"production-science-pack", 1}, {"high-tech-science-pack", 1}, {"space-science-pack", 1}
}

non_combat_bobs =
{
    {"automation-science-pack", 1}, {"science-pack-2", 1}, {"chemical-science-pack", 1},
    {"logistic-science-pack", 1}, {"production-science-pack", 1}, {"high-tech-science-pack", 1}, {"space-science-pack", 1}
}

pack_set_c =
{
    {"automation-science-pack", 1}, {"science-pack-2", 1}, {"chemical-science-pack", 1},
    {"military-science-pack", 1}, {"high-tech-science-pack", 1}, {"space-science-pack", 1}
}
